char *cvt(char *utf8){
    return utf8;
}
const char *dvt(const char *utf8){
    return utf8;
}
