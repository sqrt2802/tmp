sqrtools v2.2.1 - 名字竞技场小工具

使用步骤：
1. 准备一个 g++ 编译器并把它 symlink 到 ./g++
2. 运行 make 获得帮助（编译过程中会使用一些 shell 命令，非 Linux 系统请自行修改 makefile）
3. 编译得到 sqrtools.exe，运行 sqrtools.exe help

sqrtools 是由 powerless 等神仙玩家们开发的算号代码改装的。
v2.x 已经停止更新，访问 sqrt2802.github.io/sqrtools/ 可查看版本状态。
