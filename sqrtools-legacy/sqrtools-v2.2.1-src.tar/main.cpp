#include "utils.hpp"
const char* cmd[3]={"help","prop","skill"};
int main(int argc,char *argv[]){
    int now=-1;
    for(int i=0;i<3;++i){
        if(strcmp(argv[1],cmd[i])==0){
            now=i;
            break;
        }
    }
    switch(now){
        case 0:
            help();
            break;
        case 1:
            if(argc!=3){
                printf("%s",dvt("用法: prop <名字>\n如果输入的名字含有空格，在名字的首尾处加上英文双引号。\n"));
                break;
            }
            prop(argv[2]);
            break;
        case 2:
            if(argc!=5){
                printf("%s",dvt("用法: skill <名字> <排序方式> <空技能处理方式>\n\n"));
                printf("%s",dvt("排序方式:\nfreq - 熟练度降序\nid - 技能ID升序\nnone - 不排序\n\n"));
                printf("%s",dvt("空技能处理方式:\n0 - 不输出\n1 - 输出\n\n"));
                printf("%s",dvt("如果输入的名字含有空格，在名字的首尾处加上英文双引号。\n需要注意的是，技能熟练度有上限(104)，与评分测试中的“技能发动频率”不同。\n"));
                break;
            }
            skill(argv[2],argv[3],argv[4]);
            break;
        default:
            printf("%s %s\n",dvt("E: 错误的命令"),argv[1]);
            break;
    }
    return 0;
}
