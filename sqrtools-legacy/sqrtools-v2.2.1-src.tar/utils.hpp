#include "namerena.hpp"
void help(){
    printf("%s",dvt("sqrtools - 名字竞技场小工具\n"));
    printf("%s",dvt("v2.2.1 | sqrt2802, August 2023.\n"));
    printf("%s",dvt("命令列表:\nhelp - 输出帮助\nprop - 计算名字属性\nskill - 计算名字技能\n"));
    return;
}
void prop(char *namestr){
    int nameprop[8];
    Name name;
    if(!name.load(namestr)){
        printf("%s",dvt("E: 名字或战队名为空，请检查输入。\n"));
        return;
    }
    name.calcprops(nameprop);
    printf("%d ",nameprop[7]);
    for(int i=0;i<7;++i)
        printf("%d ",nameprop[i]+36);
    printf("\n");
    return;
}
void skill(char *namestr,char *sortmtd,char *outmtd){
    const char* skillname[40]={"火球术","冰冻术","雷击术","地裂术","吸血攻击","投毒","连击","会心一击","瘟疫","生命之轮","狂暴术","魅惑","加速术","减速术","诅咒","治愈魔法","苏生术","净化","铁壁","蓄力","聚气","潜行","血祭","分身","幻术","防御","守护","伤害反弹","护身符","护盾","反击","吞噬","召唤亡灵","垂死抗争","隐匿","空","空","空","空","空"};
    Name name;
    if(!name.load(namestr)){
        printf("%s",dvt("E: 名字或战队名为空，请检查输入。\n"));
        return;
    }
    name.calcskill();
    if(!strcmp(sortmtd,"freq"))
        std::sort(name.nameskill,name.nameskill+40,[](auto x,auto y){return x.freq>y.freq;});
    else if(!strcmp(sortmtd,"id"))
        std::sort(name.nameskill,name.nameskill+40,[](auto x,auto y){return x.id<y.id;});
    else if(strcmp(sortmtd,"none")!=0){
        printf("%s %s\n",dvt("E: 错误的排序方式"),sortmtd);
        return;
    }
    if(strcmp(outmtd,"0")&&strcmp(outmtd,"1")){
        printf("%s %s\n",dvt("E: 错误的输出方式"),outmtd);
        return;
    }
    for(int i=0;i<40;++i){
        if(!name.nameskill[i].freq){
            if(strcmp(outmtd,"0")==0){
                if(strcmp(sortmtd,"freq")==0)
                    break;
                else
                    continue;
            }
        }
        printf("%s%d ",dvt(skillname[name.nameskill[i].id]),name.nameskill[i].freq);
    }
    printf("\n");
    return;
}
