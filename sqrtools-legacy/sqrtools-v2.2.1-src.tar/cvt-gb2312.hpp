#include<windows.h>
char *cvt(char *gb2312){
    int len=MultiByteToWideChar(CP_ACP,0,gb2312,-1,NULL,0);
    wchar_t *wstr=new wchar_t[len+1];
    memset(wstr,0,len+1);
    MultiByteToWideChar(CP_ACP,0,gb2312,-1,wstr,len);
    len=WideCharToMultiByte(CP_UTF8,0,wstr,-1,NULL,0,NULL,NULL);
    char *str=new char[len+1];
    memset(str,0,len+1);
    WideCharToMultiByte(CP_UTF8,0,wstr,-1,str,len,NULL,NULL);
    if(wstr)
        delete[] wstr;
    return str;
}
char *dvt(const char *p){
    DWORD dwNum=MultiByteToWideChar(CP_UTF8,0,p,-1,NULL,0);
    char *psText;
    wchar_t *pwText=(wchar_t *)malloc(dwNum * sizeof(wchar_t));
    dwNum=MultiByteToWideChar(CP_UTF8,0,p,-1,pwText,dwNum);
    dwNum=WideCharToMultiByte(CP_ACP,0,pwText,-1,NULL,0,NULL,NULL);
    psText=(char *)malloc(dwNum * sizeof(char));
    dwNum=WideCharToMultiByte(CP_ACP,0,pwText,-1,psText,dwNum,NULL,NULL);
    free(pwText);
    return psText;
}
